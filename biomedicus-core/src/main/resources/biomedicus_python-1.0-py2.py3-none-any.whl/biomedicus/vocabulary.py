import os
import re
from abc import abstractmethod
from typing import Optional, AnyStr, Iterable, Tuple, List

import numpy as np
from tensorflow.python.lib.io import file_io

from biomedicus.tokenization import Token

PADDING = 'PADDING'


class Vocabulary(object):
    """The character, label, and word embeddings vocabulary.


    :ivar model:  The fast text model for word embeddings.
    """

    def __init__(self, directory, words_model_file=None):
        self.character_to_id = {
            PADDING: 0,
            'TOKEN_BEGIN': 1,
            'TOKEN_END': 2,
            'PREV_TOKEN': 3,
            'NEXT_TOKEN': 4,
            'SEGMENT_BEGIN': 5,
            'SEGMENT_END': 6,
            '\n': 7,
            '\t': 8,
            ' ': 9,
            'IDENTIFIER': 10
        }
        self.characters = len(self.character_to_id)
        self.label_to_id = {}
        self.id_to_label = []
        self.labels = len(self.label_to_id)
        self.word_to_id = {
            'UNKNOWN': 0
        }
        self.word_vectors = []

        with file_io.FileIO(os.path.join(directory, 'characters.txt'), 'r') as f:
            for char in f:
                self.character_to_id[char[:-1]] = len(self.character_to_id)
            self.characters = len(self.character_to_id)

        with file_io.FileIO(os.path.join(directory, 'tags.txt'), 'r') as f:
            for tag in f:
                tag = tag.strip()
                if len(tag) > 0:
                    label_id = len(self.label_to_id)
                    self.label_to_id[tag] = label_id
                    self.id_to_label.append(tag)

            self.labels = len(self.label_to_id)
            self.label_to_id[PADDING] = self.labels
            self.id_to_label.append(PADDING)
            self.labels = len(self.label_to_id)

        if words_model_file is not None:
            with file_io.FileIO(os.path.join(directory, words_model_file), 'r') as f:
                for line in f:
                    split = line.split()
                    if len(split) == 2:
                        self.word_vectors.append(np.zeros(int(split[1]), dtype='float32'))
                    else:
                        word = split[0]
                        word_id = len(self.word_vectors)
                        self.word_to_id[word] = word_id
                        self.word_vectors.append(np.asarray(split[1:], dtype='float32'))

            self.word_vectors = np.vstack(self.word_vectors)
            self.words = self.word_vectors.shape[0]

    def get_word_dimension(self):
        return self.word_vectors.shape[-1]

    def get_word_id(self, token_text, is_identifier=False):
        word = re.sub(r'[^A-Za-z0-9]', ' ', token_text)
        word = word.lower()
        word = word.replace('1', 'one')
        word = word.replace('2', 'two')
        word = word.replace('3', 'three')
        word = word.replace('4', 'four')
        word = word.replace('5', 'five')
        word = word.replace('6', 'six')
        word = word.replace('7', 'seven')
        word = word.replace('8', 'eight')
        word = word.replace('9', 'nine')
        word = word.replace('0', 'zero')
        if not word.isspace() and not is_identifier:
            word_id = self.word_to_id.get(word, 0)
        else:
            word_id = 0
        return word_id

    def label_id_not_padding(self, label_id: int) -> bool:
        return label_id != self.label_to_id[PADDING]

    def get_label(self, label_id: int) -> Optional[AnyStr]:
        return self.id_to_label[label_id] if label_id < len(self.id_to_label) else None


def _split_token_line(line: Optional[str]) -> Optional[Token]:
    if not line:
        return None

    split = line.split()

    if len(split) < 5:
        return None

    return Token(int(split[0]), int(split[1]), int(split[2]), split[3], split[4] == '1')


def directory_labels_generator(directory: AnyStr, repeat=False) -> Iterable[Tuple[AnyStr, List[Token]]]:
    while True:
        for doc in file_io.get_matching_files(os.path.join(directory, '*.txt')):
            print("reading document {}".format(doc))
            with file_io.FileIO(doc, 'r') as f:
                txt = f.read()

            with file_io.FileIO(doc.replace('.txt', '.labels'), 'r') as f:
                tokens = [_split_token_line(x) for x in next(f, None)]

            yield txt, tokens

        if not repeat:
            break


class TokenSequenceGenerator(Iterable):
    def __init__(
            self,
            input_source: Iterable[Tuple[AnyStr, List[Token]]],
            batch_size,
            sequence_length
    ):
        self.input_source = input_source
        self.batch_size = batch_size
        self.sequence_length = sequence_length

        self.batch_count = 0
        self.sequence_count = 0

        self.txt = None

        self.prev = None
        self.current = None
        self.next = None

    def __iter__(self):
        for txt, tokens in self.input_source:
            self.txt = txt

            it = iter(tokens)
            self.current = next(it, None)

            while self.current:
                self.next = next(it, None)

                self._handle_token()
                self.sequence_count += 1

                if self._sequence_full() or self._end_of_sequence():
                    self._finish_sequence()
                    self.batch_count += 1
                    self.sequence_count = 0
                    if self.batch_count == self.batch_size:
                        yield self._batch()
                        self.batch_count = 0

                self.prev = self.current
                self.current = self.next

        yield self._batch()

    def _sequence_full(self):
        return self.sequence_length == self.sequence_count

    def _end_of_sequence(self):
        return self.sequence_length > 0 and (not self.next or self.current.segment != self.next.segment)

    @abstractmethod
    def _handle_token(self):
        pass

    @abstractmethod
    def _finish_sequence(self):
        pass

    @abstractmethod
    def _batch(self):
        pass


class CountBatches(TokenSequenceGenerator):
    def __init__(self, directory, batch_size=None, sequence_length=None):
        super(CountBatches, self).__init__(directory, batch_size, sequence_length, False)

    def _handle_token(self):
        pass

    def _finish_sequence(self):
        pass

    def _return_data(self):
        return 1


def _map_to_ints(string):
    return [ord(x) for x in string]


def _strings(ints):
    return [str(x) for x in ints]
