import re
from typing import Iterable, Tuple, NamedTuple, Optional

Token = NamedTuple('Token',
                   [('segment', int),
                    ('begin', int),
                    ('end', int),
                    ('label', Optional[int]),
                    ('is_identifier', Optional[int]),
                    ('has_space_after', bool)])

_segment_pattern = re.compile(r"\n{2,}|\Z", re.M)
_token_pattern = re.compile(r"(^=+$)|(^-+$)|[A-Za-z]+|\S", re.M)


def tokenize(txt: str) -> Iterable[Token]:
    segment_start = 0
    for segment_index, segment in enumerate(_segment_pattern.finditer(txt)):
        segment_end = segment.start()
        for token in _token_pattern.finditer(txt, segment_start, segment_end):
            has_space_after = txt[token.end():token.end() + 1].isspace() if token.end() < len(txt) else False
            yield Token(segment_index,
                        token.start(),
                        token.end(),
                        None,
                        None,
                        has_space_after)

        segment_start = segment.end()

