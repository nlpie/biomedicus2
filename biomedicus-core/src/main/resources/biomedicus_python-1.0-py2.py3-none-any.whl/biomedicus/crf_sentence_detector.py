from keras.layers import Input, Embedding, TimeDistributed, Flatten
from keras.models import Model
from keras_contrib.layers import CRF

from biomedicus.vocabulary import TokenSequenceGenerator


class CharFeatureReader(TokenSequenceGenerator):
    def __init__(self,
                 directory,
                 vocabulary,
                 repeat=True,
                 batch_size=None,
                 sequence_length=None,
                 pre_word=7,
                 start_word=7,
                 end_word=7,
                 post_word=7
                 ):
        super(CharFeatureReader, self).__init__(directory, batch_size, sequence_length, repeat)

        self.vocabulary = vocabulary

        self.pre_word = pre_word
        self.start_word = start_word
        self.end_word = end_word
        self.post_word = post_word

        self.batch_chars = []
        self.batch_labels = []
        self.batch_weights = []

        self.minibatch_chars = []
        self.minibatch_labels = []
        self.minibatch_weights = []


class CRFSentenceDetector(object):

    @staticmethod
    def default_conf(vocabulary, **kwargs):
        config = {
            'dim_char': 30,
            'characters': vocabulary.characters,
            'labels': vocabulary.labels,
            'pre_word': 7,
            'start_word': 7,
            'end_word': 7,
            'post_word': 7
        }
        config.update(kwargs)
        return config

    def __init__(self, config):
        self.config = config

        character_features = config['pre_word'] + config['start_word'] + config['end_word'] + \
                             config['post_word']
        char_input = Input(shape=(None, character_features), name='char_input')

        characters = config['characters']
        dim_char = config['dim_char']
        embeddings = TimeDistributed(Embedding(input_dim=characters,
                                               output_dim=dim_char))(char_input)

        words = TimeDistributed(Flatten())(embeddings)

        labels = config['labels']
        predict = CRF(labels, sparse_target=True)(words)

        self.model = Model(inputs=[char_input], outputs=[predict])
