from __future__ import division

import os
from argparse import ArgumentParser
from time import time
from typing import Optional, AnyStr, List, Union, Tuple, Iterable

import keras
import numpy
import yaml
from keras import Input, Model
from keras.callbacks import EarlyStopping
from keras.layers import Bidirectional, LSTM, TimeDistributed, Dense, Masking, Embedding, Conv1D, \
    GlobalMaxPooling1D, concatenate
from keras.optimizers import SGD
from keras.utils import to_categorical
from keras_contrib.layers.crf import CRF
from keras_preprocessing.sequence import pad_sequences
from sklearn.metrics import precision_recall_fscore_support

from biomedicus.tokenization import tokenize, Token
from .vocabulary import TokenSequenceGenerator, Vocabulary, directory_labels_generator

WORD_INPUT = 'word_input'  # The name for the word input tensor

CHAR_INPUT = 'char_input'  # The name for the char input tensor


class BiLSTMSentenceDetector(object):
    """A sentence detector that does sequence detection using a character representation of words
    and/or a word embedding representation of words that a bidirectional LSTM uses to create a
    contextual word representation before passing it to a CRF

    """

    @staticmethod
    def hparams_parser() -> ArgumentParser:

        parser = ArgumentParser()
        parser.add_argument('--epochs', type=int,
                            help="number of epochs to run training. defaults to 100.")
        parser.add_argument('--batch-size', type=int,
                            help="number of sequences per minibatch. defaults to 32.")
        parser.add_argument('--sequence-length', type=int,
                            help="number of words per sequence. defaults to to 32.")
        parser.add_argument('--use-chars', type=bool,
                            help="whether to use the character model. defaults to True")
        parser.add_argument('--word-length', type=int,
                            help="number of characters per word. defaults to 32.")
        parser.add_argument('--dim-char', type=int,
                            help="length of learned char embeddings. default is 30.")
        parser.add_argument('--use-token-boundaries', type=bool,
                            help="whether to insert characters representing the begin and ends of "
                                 "words. default is True")
        parser.add_argument('--use-neighbor-boundaries', type=bool,
                            help="whether to insert characters representing the end of the "
                                 "previous neighbor and the begin of the next neighbor token. "
                                 "default is True")
        parser.add_argument('--use-sequence-boundaries', type=bool,
                            help="whether to insert characters representing the begin of a "
                                 "segment (piece of text whose boundaries are guaranteed to "
                                 "not have a sentence spanning). default is True")
        parser.add_argument('--char-mode', choices=['cnn', 'lstm'],
                            help="the method to use for character representations. either 'cnn' for "
                                 "convolutional neural networks or 'lstm' for a bidirectional lstm. "
                                 "default is 'cnn'.")
        parser.add_argument('--char-cnn-filters', type=int,
                            help="the number of filters for a CNN character representation. "
                                 "default is 100.")
        parser.add_argument('--char-cnn-kernel-size', type=int,
                            help="the kernel size (number of character embeddings to look at). "
                                 "default is 3.")
        parser.add_argument('--char-lstm-hidden-size', type=int,
                            help="when using bi-lstm the output dimensionality of the bi-lstm. "
                                 "default is 25.")
        parser.add_argument('--use-words', type=bool,
                            help="whether to use word embedding word representations. default is True.")
        parser.add_argument('--lstm-hidden-size', type=bool,
                            help="the output dimensionality of the contextual word representation "
                                 "bi-lstm layer. default is 300.")
        parser.add_argument('--output-mode', choices=['dense', 'crf'],
                            help="the method to use for the output layer. Either 'dense' for a Dense "
                                 "layer or 'crf' for a linear-chain conditional random field layer. "
                                 "default is 'crf'.")
        parser.add_argument('--optimizer',
                            help="the keras optimizer to use. default is 'adam'")
        parser.add_argument('--dropout', type=float,
                            help="the input/output dropout for the bi-lstms in the network during "
                                 "training. default is .2.")
        parser.add_argument('--recurrent-dropout', type=float,
                            help="the recurrent dropout for the bi-lstms in the network. "
                                 "default is .2.")
        parser.add_argument('--tensorboard', action='store_true',
                            help="whether to use a keras.callbacks.TensorBoard. default is False.")
        parser.add_argument("--checkpoints", type=bool,
                            help="whether to save the best model during training. default is True.")
        parser.add_argument("--early-stopping", type=bool,
                            help="whether to stop when the model stops improving. default is True.")
        parser.add_argument("--early-stopping-patience", type=int,
                            help="how many epochs without improvement before stopping. "
                                 "default is 5.")
        parser.add_argument("--early-stopping-delta", type=float,
                            help="the smallest amount loss needs to improve by to be considered "
                                 "improvement by early stopping. default is 0.001")
        parser.add_argument("--use-class-weights", type=bool,
                            help="whether to weight the value of class loss and accuracy based on "
                                 "their support. default is True.")
        parser.add_argument("--o-weight-modifier", type=float,
                            help="the multiplier to modify the weight of the loss and accuracy from "
                                 "'O' samples. default is 1.")
        parser.add_argument("--continue-sgd", type=bool,
                            help="whether to start training with the specified optimizer and continue "
                                 "training with an SGD optimizer when an epoch doesn't improve loss by "
                                 "0.005. default is False.")
        parser.add_argument("--validation-split", type=float,
                            help="the fraction of the data to use for validation. default is 0.2.")

        return parser

    def __init__(self,
                 vocabulary: Vocabulary,
                 epochs: int = None,
                 batch_size: int = None,
                 sequence_length: int = None,
                 use_chars: bool = None,
                 word_length: int = None,
                 dim_char: int = None,
                 use_token_boundaries: bool = None,
                 use_neighbor_boundaries: bool = None,
                 use_sequence_boundaries: bool = None,
                 char_mode: str = None,
                 char_cnn_filters: int = None,
                 char_cnn_kernel_size: int = None,
                 char_lstm_hidden_size: int = None,
                 use_words: bool = None,
                 lstm_hidden_size: int = None,
                 output_mode: str = None,
                 optimizer: str = None,
                 dropout: float = None,
                 recurrent_dropout: float = None,
                 tensorboard: bool = None,
                 checkpoints: bool = None,
                 early_stopping: bool = None,
                 early_stopping_patience: int = None,
                 early_stopping_delta: float = None,
                 use_class_weights: bool = None,
                 o_weight_modifier: float = None,
                 continue_sgd: bool = None,
                 validation_split: float = None,
                 **_):
        """Creates a Bi-LSTM sentence detector using the designated hparams

        :param epochs: number of epochs to run training. default is 100.
        :param batch_size: number of sequences per minibatch. default is 32.
        :param sequence_length: number of words per sequence. default is 32.
        :param use_chars: whether to use the character model. default is True.
        :param word_length: number of characters per word. default is 32.
        :param dim_char: length of learned char embeddings. default is 30.
        :param use_token_boundaries: whether to insert characters representing the begin and ends of
                                     words. default is True
        :param use_neighbor_boundaries: whether to insert characters representing the end of the
                                        previous neighbor and the begin of the next neighbor token.
                                        default is True
        :param use_sequence_boundaries: whether to insert characters representing the begin of a
                                        segment (piece of text whose boundaries are guaranteed to
                                        not have a sentence spanning). default is True
        :param char_mode: the method to use for character representations. either 'cnn' for
                          convolutional neural networks or 'lstm' for a bidirectional lstm.
                          default is 'cnn'.
        :param char_cnn_filters: the number of filters for a CNN character representation.
                                 default is 100.
        :param char_cnn_kernel_size: the kernel size (number of character embeddings to look at).
                                     default is 3.
        :param char_lstm_hidden_size: when using bi-lstm the output dimensionality of the bi-lstm.
                                      default is 25.
        :param use_words: whether to use word embedding word representations. default is True.
        :param lstm_hidden_size: the output dimensionality of the contextual word representation
                                 bi-lstm layer. default is 300.
        :param output_mode: the method to use for the output layer. Either 'dense' for a Dense layer
                            or 'crf' for a linear-chain conditional random field layer.
                            default is 'crf'.
        :param optimizer: the keras optimizer to use.
        :param dropout: the input/output dropout for the bi-lstms in the network during training.
                        default is .5.
        :param recurrent_dropout: the recurrent dropout for the bi-lstms in the network.
                                  default is .75.
        :param tensorboard: whether to use a keras.callbacks.TensorBoard. default is False.
        :param checkpoints: whether to save the best model during training. default is False.
        :param early_stopping: whether to stop when the model stops improving. default is True.
        :param early_stopping_patience: how many epochs without improvement before stopping.
                                        default is 5.
        :param early_stopping_delta: the smallest amount loss needs to improve by to be considered
                                     'improvement' by early stopping. default is 0.001
        :param use_class_weights: whether to weight the value of class loss and accuracy based on
                                  their support. default is True.
        :param o_weight_modifier: the multiplier to modify the weight of the loss and accuracy from
                                  'O' samples. default is 1.
        :param continue_sgd: whether to start training with the specified optimizer and continue
                             training with an SGD optimizer when an epoch doesn't improve loss by
                             0.005. default is False.
        :param validation_split: the fraction of the data to use for validation. default is 0.2.
        :param _: unused additional params, so we can pass argparse dicts.
        """
        del _

        self.vocabulary = vocabulary

        self.labels = vocabulary.labels
        self.chars = vocabulary.characters

        self.words = vocabulary.words
        self.word_embeddings = vocabulary.word_vectors
        self.dim_word = vocabulary.get_word_dimension()

        self.epochs = epochs or 100
        self.batch_size = batch_size or 32
        self.sequence_length = sequence_length or 32

        self.use_chars = use_chars or True

        self.word_length = word_length or 32
        self.dim_char = dim_char or 30

        self.use_token_boundaries = use_token_boundaries or True
        self.use_neighbor_boundaries = use_neighbor_boundaries or True
        self.use_sequence_boundaries = use_sequence_boundaries or True

        self.char_mode = char_mode or 'cnn'

        self.char_cnn_filters = char_cnn_filters or 100
        self.char_cnn_kernel_size = char_cnn_kernel_size or 3

        self.char_lstm_hidden_size = char_lstm_hidden_size or 25

        self.use_words = use_words or True

        self.lstm_hidden_size = lstm_hidden_size or 300

        self.output_mode = output_mode or 'crf'

        self.optimizer = optimizer or 'adam'

        self.dropout = dropout or .2
        self.recurrent_dropout = recurrent_dropout or .2

        self.tensorboard = tensorboard or False
        self.checkpoints = checkpoints or False

        self.early_stopping = early_stopping or True
        self.early_stopping_patience = early_stopping_patience or 5
        self.early_stopping_delta = early_stopping_delta or .001

        self.use_class_weights = use_class_weights or True
        self.o_weight_modifier = o_weight_modifier or 1.

        self.continue_sgd = continue_sgd or False

        self.validation_split = validation_split or .2

        self.crf, self.model = self._build_model()

    def _build_model(self) -> (Optional[CRF], Model):
        char_input = None
        chars_embedding = None
        if self.use_chars:
            char_input = Input(shape=(self.sequence_length, self.word_length), name=CHAR_INPUT)
            char_embedding = TimeDistributed(Embedding(input_dim=self.chars,
                                                       output_dim=self.dim_char,
                                                       dtype='float32',
                                                       mask_zero=self.char_mode == 'lstm'),
                                             dtype='float32',
                                             name='char_embedding')(char_input)

            if self.char_mode == 'cnn':
                char_cnn = TimeDistributed(Conv1D(self.char_cnn_filters,
                                                  self.char_cnn_kernel_size,
                                                  padding='same'),
                                           name='char_cnn')(char_embedding)
                chars_embedding = TimeDistributed(GlobalMaxPooling1D(), name='char_pooling')(
                    char_cnn)
            else:

                chars_embedding = TimeDistributed(
                    Bidirectional(LSTM(units=self.char_lstm_hidden_size,
                                       dropout=self.dropout,
                                       recurrent_dropout=self.recurrent_dropout)),
                    name='chars_word_embedding')(char_embedding)
        if self.use_words:
            word_input = Input(shape=(self.sequence_length,), name=WORD_INPUT)
            word_embedding = Embedding(input_dim=self.words,
                                       output_dim=self.dim_word,
                                       weights=[self.word_embeddings],
                                       mask_zero=False,
                                       dtype='float32',
                                       name='word_embedding_input',
                                       trainable=False)(word_input)
            if chars_embedding is not None:
                inputs = [char_input, word_input]
                word_embedding = concatenate([chars_embedding, word_embedding],
                                             name='word_representation')
            else:
                inputs = [word_input]
                word_embedding = word_embedding
        else:
            inputs = [char_input]
            word_embedding = chars_embedding
        context = Bidirectional(LSTM(self.lstm_hidden_size,
                                     return_sequences=True,
                                     dropout=self.dropout,
                                     recurrent_dropout=self.recurrent_dropout,
                                     return_state=False),
                                name='contextual_word_representation')(
            Masking()(word_embedding))

        crf = None
        if self.output_mode == 'crf':
            crf = CRF(self.labels)
            logits = crf(context)
        else:
            logits = TimeDistributed(Dense(self.labels, activation='softmax'),
                                     name='logits')(context)

        model = keras.Model(inputs=inputs, outputs=[logits])

        return crf, model

    def hparams(self):
        return '\n'.join(["{}: {}".format(key, self.__getattribute__(key)) for key in (
            'labels',
            'chars',
            'words',
            'dim_word',
            'epochs',
            'batch_size',
            'sequence_length',
            'use_chars',
            'word_length',
            'dim_char',
            'use_token_boundaries',
            'use_neighbor_boundaries',
            'char_mode',
            'char_cnn_filters',
            'char_cnn_kernel_size',
            'use_words',
            'lstm_hidden_size',
            'output_mode',
            'optimizer',
            'dropout',
            'recurrent_dropout',
            'checkpoints',
            'early_stopping',
            'early_stopping_patience',
            'early_stopping_delta',
            'use_class_weights',
            'o_weight_modifier',
            'continue_sgd',
            'validation_split'
        )])

    def train_model(self, job_dir, data_dir, vocabulary):
        print('training with config:\n')
        print(self.hparams())

        log_name = self._build_log_name()

        callbacks = []

        metrics = Metrics(vocabulary, use_chars=self.use_chars, use_words=self.use_words)
        callbacks.append(metrics)

        if self.tensorboard:
            log_path = os.path.join(job_dir, "logs", log_name)
            tensorboard = keras.callbacks.TensorBoard(log_dir=log_path)
            callbacks.append(tensorboard)

        labels_generator = directory_labels_generator(os.path.join(data_dir, "data"))
        generator = InputGenerator(labels_generator,
                                   vocabulary,
                                   batch_size=-1,
                                   sequence_length=self.sequence_length,
                                   use_chars=self.use_chars,
                                   use_words=self.use_words,
                                   use_neighbor_boundaries=self.use_neighbor_boundaries,
                                   use_sequence_boundaries=self.use_sequence_boundaries,
                                   use_token_boundaries=self.use_token_boundaries,
                                   word_length=self.word_length)

        train = next(iter(generator))

        real_classes = generator.class_counts[:-1]
        total = sum(real_classes)

        class_weights = None
        if self.use_class_weights:
            class_weights = [total / (len(real_classes) * x) for x in real_classes] + [0.]
            class_weights[vocabulary.label_to_id['O']] *= self.o_weight_modifier

        if self.checkpoints:
            checkpoint = keras.callbacks.ModelCheckpoint(
                os.path.join(job_dir, 'models', log_name + '-weights.hdf5'),
                verbose=1,
                save_best_only=True
            )
            callbacks.append(checkpoint)

        if self.continue_sgd:
            self._continue_sgd(train, class_weights, callbacks)
        else:
            self._train_once(train, class_weights, callbacks)

    def _build_log_name(self):
        log_name = ''
        if self.use_words:
            if self.char_mode == 'cnn':
                log_name += '{}dim{}size{}lengthCharCNN-'.format(self.dim_char,
                                                                 self.char_cnn_filters,
                                                                 self.char_cnn_kernel_size)
            else:
                log_name += '{}dim{}sizeCharLSTM-'.format(self.dim_char,
                                                          self.char_lstm_hidden_size)
        if self.use_chars:
            log_name += '{}dimWords-'.format(self.dim_word)
        log_name += '{}unitLSTM-'.format(self.lstm_hidden_size)
        if self.output_mode == 'crf':
            log_name += 'crf-'
        log_name += '{}sequences-{}batches-{}-{}'.format(self.sequence_length,
                                                         self.batch_size,
                                                         self.optimizer,
                                                         time())
        return log_name

    def _train_once(self, train, class_weights, callbacks):
        self._compile_model(optimizer=self.optimizer)

        if self.early_stopping:
            stopping = keras.callbacks.EarlyStopping(
                patience=self.early_stopping_patience,
                min_delta=self.early_stopping_delta)
            callbacks.append(stopping)

        self.model.fit(train[0],
                       train[1],
                       batch_size=self.batch_size,
                       epochs=self.epochs,
                       class_weight=class_weights,
                       validation_split=self.validation_split,
                       callbacks=callbacks)

    def _continue_sgd(self, train, class_weights, callbacks):
        self._compile_model(optimizer=self.optimizer)

        history = self.model.fit(train[0],
                                 train[1],
                                 batch_size=self.batch_size,
                                 class_weight=class_weights,
                                 epochs=self.epochs,
                                 validation_split=self.validation_split,
                                 callbacks=callbacks + [EarlyStopping(min_delta=0.005)])

        print("Continuing training using SGD")

        self._compile_model(optimizer=SGD(momentum=0.9, nesterov=True))

        if self.early_stopping:
            stopping = keras.callbacks.EarlyStopping(
                patience=self.early_stopping_patience,
                min_delta=self.early_stopping_delta)
            callbacks.append(stopping)

        i = len(history.epoch)
        if i < self.epochs:
            self.model.fit(train[0],
                           train[1],
                           batch_size=self.batch_size,
                           class_weight=class_weights,
                           epochs=self.epochs,
                           validation_split=self.validation_split,
                           initial_epoch=i,
                           callbacks=callbacks)

    def _compile_model(self, optimizer: Union[AnyStr, keras.optimizers.Optimizer]):
        if self.output_mode == 'crf':
            self.model.compile(optimizer=optimizer,
                               loss=self.crf.loss_function,
                               weighted_metrics=[self.crf.accuracy])
        else:
            self.model.compile(optimizer=optimizer,
                               loss='categorical_crossentropy',
                               weighted_metrics=['categorical_accuracy'])

    def save_config(self, file_path: AnyStr):
        """Saves a yaml containing a dictionary that can be used to re-construct the model.

        :parameter file_path: The path to write the file to.
        """
        config = dict(self.__dict__)
        config.pop("vocabulary")
        config.pop("labels")
        config.pop("chars")
        config.pop("words")
        config.pop("word_embeddings")
        config.pop("dim_word")
        config.pop("crf")
        config.pop("model")

        with open(file_path, 'w') as out:
            yaml.dump(config, out, default_flow_style=False)

    def save_weights(self, file_path: AnyStr, overwrite: bool = True):
        self.model.save_weights(file_path, overwrite=overwrite)

    def load_weights(self, file_path: AnyStr):
        self.model.load_weights(file_path)

    def predict_txt(self, txt: AnyStr, tokens: Optional[List[Token]] = None) -> List[List[Token]]:
        """Takes input text, tokenizes it, and then returns a list of tokens with labels

        :param txt: the text to predict sentences
        :param tokens: tokens if the text has already been tokenized
        :return: a list of lists of tokens with their sentence classifications. Each list is a
        sentence or continuous Outside / Unknown tokens.
        """
        if tokens is None:
            tokens = list(tokenize(txt))

        generator = InputGenerator([(txt, tokens)],
                                   vocabulary=self.vocabulary,
                                   sequence_length=self.sequence_length,
                                   word_length=self.word_length,
                                   use_chars=self.use_chars,
                                   use_token_boundaries=self.use_token_boundaries,
                                   use_neighbor_boundaries=self.use_neighbor_boundaries,
                                   use_sequence_boundaries=self.use_sequence_boundaries,
                                   include_labels=False,
                                   use_words=self.use_words)
        inputs = next(iter(generator))

        outputs = self.model.predict(inputs, batch_size=self.batch_size)
        outputs = numpy.argmax(outputs, axis=-1).ravel()
        outputs = [self.vocabulary.get_label(x) for x in outputs if self.vocabulary.label_id_not_padding(x)]

        results = []
        prev = None
        sentence = []
        for token, label in zip(tokens, outputs):
            token = Token(token.segment, token.begin, token.end, label, token.is_identifier, token.has_space_after)
            if prev is not None and ((token.label == 'B') or (token.label == 'O' and prev.label != 'O')):
                if len(sentence) > 0:
                    results.append(sentence)
                    sentence = []

            sentence.append(token)

            prev = token

        if len(sentence) > 0:
            results.append(sentence)

        return results


class InputGenerator(TokenSequenceGenerator):
    def __init__(self,
                 input_source: Iterable[Tuple[AnyStr, List[Token]]],
                 vocabulary: Vocabulary,
                 sequence_length: int,
                 word_length: int,
                 use_chars: bool,
                 use_words: bool,
                 use_token_boundaries: bool,
                 use_neighbor_boundaries: bool,
                 use_sequence_boundaries: bool,
                 include_labels: bool = True,
                 batch_size: int = -1):
        super().__init__(input_source, batch_size, sequence_length)
        self.vocabulary = vocabulary

        self.word_length = word_length

        self.use_chars = use_chars
        self.use_words = use_words
        self.use_token_boundaries = use_token_boundaries
        self.use_neighbor_boundaries = use_neighbor_boundaries
        self.use_sequence_boundaries = use_sequence_boundaries

        self.txt = None

        self.batch_count = 0
        self.chars = []
        self.words = []
        self.labels = []

        self.sequence_count = 0
        self.segment_chars = []
        self.segment_words = []
        self.segment_labels = []

        self.prev = None
        self.current = None
        self.next = None

        self.include_labels = include_labels

        self.class_counts = [0 for _ in range(0, vocabulary.labels)]

        self.first_word = True

    def _handle_token(self):
        if self.use_chars:
            chars = self._get_chars()
            self.segment_chars.append(chars)

        if self.use_words:
            word_id = self.vocabulary.get_word_id(self.txt[self.current.begin:self.current.end],
                                                  is_identifier=self.current.is_identifier)
            self.segment_words.append(word_id)

        if self.include_labels:
            label_id = self.vocabulary.label_to_id[self.current.label]
            self.class_counts[label_id] += 1
            self.segment_labels.append(label_id)

    def _finish_sequence(self):
        if self.use_chars:
            self.chars.append(pad_sequences(self.segment_chars,
                                            maxlen=self.word_length,
                                            padding='post',
                                            truncating='post',
                                            value=0))

        if self.use_words:
            self.words.append(self.segment_words)

        self.labels.append(self.segment_labels)

        self.segment_chars = []
        self.segment_words = []
        self.segment_labels = []
        self.first_word = True

    def _batch(self):
        inputs = {}

        if self.use_chars:
            inputs['char_input'] = pad_sequences(
                self.chars,
                maxlen=self.sequence_length,
                padding='post',
                truncating='post',
                value=0
            )
            self.chars = []
        if self.use_words:
            inputs['word_input'] = pad_sequences(
                self.words,
                maxlen=self.sequence_length,
                padding='post',
                truncating='post',
                value=0
            )
            self.words = []

        if self.include_labels:
            labels = pad_sequences(
                self.labels,
                maxlen=self.sequence_length,
                padding='post',
                truncating='post',
                value=self.vocabulary.label_to_id['PADDING']
            )
            labels = to_categorical(labels, self.vocabulary.labels)
            self.labels = []

            return inputs, labels
        else:
            return inputs

    def _get_chars(self) -> List[AnyStr]:
        begin = self.current.begin
        end = self.current.end

        all_chars = []

        if self.prev is None:
            prev_end = max(0, begin - 7)
        else:
            prev_end = max(self.prev.end, begin - 7)

            if self.use_neighbor_boundaries:
                all_chars.append('PREV_TOKEN')

        pre = self.txt[prev_end:begin]
        all_chars += list(pre)

        if self.use_sequence_boundaries:
            if self.prev is None or self.current.segment != self.prev.segment:
                all_chars.append('SEGMENT_BEGIN')

        if self.use_token_boundaries:
            all_chars.append('TOKEN_BEGIN')

        if self.current.is_identifier:
            all_chars.append('IDENTIFIER')
        else:
            token_txt = self.txt[begin:end]
            all_chars += list(token_txt)

        if self.use_token_boundaries:
            all_chars.append('TOKEN_END')

        if self.use_sequence_boundaries:
            if self.next is None or self.current.segment != self.next.segment:
                all_chars.append('SEGMENT_END')

        if self.next is not None:
            next_begin = min(self.next.begin, end + 7)
        else:
            next_begin = min(len(self.txt), end + 7)

        post = self.txt[end:next_begin]
        all_chars += list(post)

        if self.use_neighbor_boundaries:
            all_chars.append('NEXT_TOKEN')

        return [self.vocabulary.character_to_id[i] for i in all_chars]


class Metrics(keras.callbacks.Callback):
    def __init__(self, vocabulary, use_chars, use_words):
        super(Metrics, self).__init__()
        self.vocabulary = vocabulary
        self.two = use_chars and use_words

        self.y_true = None
        self.weights = None

    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}

        if self.two:
            score = self.model.predict([self.validation_data[0], self.validation_data[1]])
            if self.y_true is None:
                self.y_true = numpy.argmax(self.validation_data[2], -1).ravel()
        else:
            score = self.model.predict(self.validation_data[0])
            if self.y_true is None:
                self.y_true = numpy.argmax(self.validation_data[1], -1).ravel()

        y_predict = numpy.argmax(score, -1).ravel()

        if self.weights is None:
            padding = self.vocabulary.label_to_id['PADDING']
            self.weights = [0. if x == padding else 1. for x in self.y_true]

        p, r, f1, s = precision_recall_fscore_support(
            self.y_true,
            y_predict,
            sample_weight=self.weights
        )

        by_label = zip(p, r, f1)

        print("label,precision,recall,f1")
        for i, metrics in enumerate(by_label):
            label = self.vocabulary.id_to_label[i] if i < self.vocabulary.labels else 'average'
            logs[label + '/precision'] = metrics[0]
            logs[label + '/recall'] = metrics[1]
            logs[label + '/f1'] = metrics[2]
            print('{},{},{},{}'.format(label, metrics[0], metrics[1], metrics[2]))
