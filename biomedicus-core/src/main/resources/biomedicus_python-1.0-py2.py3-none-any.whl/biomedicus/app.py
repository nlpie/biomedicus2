import os
from json import dumps

import yaml
from bottle import Bottle, request, response, run

from biomedicus import Vocabulary
from biomedicus import BiLSTMSentenceDetector

data = os.environ['BIOMEDICUS_SENTENCES_VOCAB']
words_model = os.environ['BIOMEDICUS_WORDS_MODEL']
config = os.environ['BIOMEDICUS_SENTENCES_CONFIG']
weights = os.environ['BIOMEDICUS_SENTENCES_WEIGHTS']

app = Bottle()

vocab_dir = os.path.join(data, 'vocab')
vocabulary = Vocabulary(vocab_dir, words_model)

bi_lstm = BiLSTMSentenceDetector(**yaml.load(config))
bi_lstm.load_weights(weights)


@app.post('/api/sentences')
def sentences():
    txt = request.json['text']
    tokens = request.json.get('tokens')

    results = bi_lstm.predict_txt(txt, tokens)

    response.content_type = 'application/json'
    return dumps({'sentences': results})


if __name__ == '__main__':
    run(host='localhost', port=8080)
