import unittest

from .tokenization import tokenize


class TestTokenize(unittest.TestCase):

    def test_split_numbers(self):
        tokens = list(tokenize("0.123456789"))

        self.assertListEqual(tokens,
                             [(0, i, i + 1, None, None, False) for i in range(0, 11)],
                             msg="Should split every number into its own token.")

    def test_split_on_whitespace(self):
        tokens = list(tokenize("hi there"))

        self.assertListEqual(tokens, [(0, 0, 2, None, None, True), (0, 3, 8, None, None, False)],
                             msg="Should split tokens on whitespace")

    def test_line_of_entirely_dash_or_equals(self):
        tokens = list(tokenize("=====\n-----\n"))

        self.assertListEqual(tokens, [(0, 0, 5, None, None, True), (0, 6, 11, None, None, True)],
                             msg="Should split a line only containing = or - into 1 token")

    def test_split_segments(self):
        tokens = list(tokenize("one segment\n\nanother"))

        self.assertListEqual(tokens, [(0, 0, 3, None, None, True),
                                      (0, 4, 11, None, None, True),
                                      (1, 13, 20, None, None, False)],
                             msg="Should correctly identify segments")

    def test_dont_match_whitespace(self):
        tokens = list(tokenize(" \n\t"))

        self.assertListEqual(tokens, [], msg="Whitespace shouldn't be tokens")
