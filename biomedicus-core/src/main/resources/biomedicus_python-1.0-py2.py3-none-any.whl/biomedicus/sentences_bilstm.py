import os
import sys

import yaml

from biomedicus import BiLSTMSentenceDetector, Vocabulary

if __name__ == "__main__":
    parser = BiLSTMSentenceDetector.hparams_parser()

    parser.add_argument('mode', choices=['train', 'predict', 'write_config'])

    parser.add_argument('-j', '--job-dir', required=False,
                        help="Path to the output directory where logs and models will be written.")
    parser.add_argument('-d', '--data-dir',
                        required=True,
                        help="Path to the data directory containing the training data "
                             "and vocabulary files")
    parser.add_argument('-w', '--word-model',
                        help="File name of the word model in the vocab dir")

    parser.add_argument("--config-file",
                        help="Yaml configuration file. Arguments specified at run take precedence "
                             "over anything in this file.")
    parser.add_argument("--config-out",
                        help="A file to write the yaml configuration of the sentence detector")

    parser.add_argument("--weights-file",
                        help="The hdf5 file to load model weights from.")

    args = parser.parse_args()

    data_dir = args.data_dir

    vocab_dir = os.path.join(data_dir, 'vocab')
    word_model = args.word_model
    vocabulary = Vocabulary(vocab_dir, word_model)

    options = {}
    if args.config_file is not None:
        with open(args.config_file, 'r') as config_file:
            options.update(yaml.load(config_file))

    options.update(args.__dict__)

    job_dir = args.job_dir or data_dir

    bi_lstm = BiLSTMSentenceDetector(vocabulary=vocabulary, **options)

    if args.weights_file is not None:
        bi_lstm.load_weights(args.weights_file)

    if args.mode == 'train':
        bi_lstm.train_model(job_dir=job_dir, data_dir=data_dir, vocabulary=vocabulary)
        if args.config_out is not None:
            bi_lstm.save_config(args.config_out)
    elif args.mode == 'write_config':
        if args.config_out is not None:
            bi_lstm.save_config(args.config_out)
    elif args.mode == 'predict':
        txt = sys.stdin.read()
        sentences = bi_lstm.predict_txt(txt)
        for sentence in sentences:
            if sentence[0].label == 'B':
                line = "[S:] "
            else:
                line = "[U:] "

            line += " ".join(map(lambda x: txt[x.begin:x.end], sentence))

            print(line)
