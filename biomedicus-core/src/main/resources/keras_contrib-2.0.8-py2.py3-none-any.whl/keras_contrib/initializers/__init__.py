from __future__ import absolute_import
from keras.initializers import *

from .convaware import ConvolutionAware
